#include<iostream>
using namespace std;

int main(){

int a,b,c;
cout<<"Enter Num1 Num2 ";
// cin>>a;
// cin>>b;
//or
cin>>a>>b;
//addition
c=a+b;
cout<<"Add="<<c<<endl;
//substraction
c=a-b;
cout<<"Subs="<<c<<endl;

//div
cout<<"Div="<<(a/b)<<endl;
//multi
c=a*b;
cout<<"Multi="<<c<<endl;



}