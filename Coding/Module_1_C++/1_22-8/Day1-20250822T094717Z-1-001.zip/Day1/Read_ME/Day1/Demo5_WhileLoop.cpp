#include<iostream>
using namespace std;

int main(){
cout<<"----While Demo-----"<<endl;
int counter=1;
while(counter<=10){
    cout<<counter<<endl;
    counter++;
}
cout<<"-------end--------"<<endl;

}