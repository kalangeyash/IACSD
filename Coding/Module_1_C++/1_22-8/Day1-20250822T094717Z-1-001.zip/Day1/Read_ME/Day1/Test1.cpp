#include<iostream>
using namespace std;

int main(){

cout<<"Welcome To CPP"<<endl;
cout<<"Welcome To IACSD "<<endl;

//declare variable for storing no1
//static
int num1=10;
//print /display value of num1

cout<<"Value Of Num1="<<num1<<endl;

//accept num2 from user....using keybord
int num2;
cout<<"Value Of Num2="<<num2<<endl;//garbage
//initialise it dynamically
cout<<"Please Enter Num2= ";
cin>>num2;
cout<<"Value Of Num2="<<num2<<endl;//

//int num3="101";//error



return 0;
}
