/**
 * 
 */
/**
 * 
 */
module MyBank {
}