package operators;

public class TestRightShiftOperator {

	public static void main(String[] args) {
		int a =20;
		System.out.println(a>>2);
		 a =-1;
		System.out.println(a>>20);
	}

}
