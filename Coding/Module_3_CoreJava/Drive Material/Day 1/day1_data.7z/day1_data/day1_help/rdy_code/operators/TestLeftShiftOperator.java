package operators;

public class TestLeftShiftOperaotr {
	public static void main(String[] args) {
		int a = 25;
		System.out.println(a<<4);//25 * 16
		a=-25;
		System.out.println(a<<4);

	}
}
