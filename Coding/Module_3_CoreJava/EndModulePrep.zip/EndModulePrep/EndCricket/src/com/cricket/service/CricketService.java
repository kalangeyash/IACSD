package com.cricket.service;
/*
 1.Accept minimum 5 Cricketers in the collection.

2.Modify Cricketer's rating

3.Search Cricketer by name

4. Display all Cricketers added in collection.

5.Display All Cricketers in sorted form by rating.

 */

import java.util.List;

import com.cricket.core.Cricketer;
import com.cricket.exception.MyCricketException;

public interface CricketService {
	
	public String addCricketer(String name, int age, String email_id,String phone ,int rating) throws MyCricketException;
	
	public String changeRating(String email_id, int rating)throws MyCricketException;
	
	public void searchCricketerByName(String name,String email_id) throws MyCricketException;
	
	public void allCricketerSummary()throws MyCricketException;
	
	public void sortByRating( )throws MyCricketException;
}


