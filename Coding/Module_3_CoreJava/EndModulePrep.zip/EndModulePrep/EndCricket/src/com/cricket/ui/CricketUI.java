package com.cricket.ui;

import java.util.Scanner;

import com.cricket.service.CricketImplementation;
import com.cricket.service.CricketService;

public class CricketUI {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
	
	
		try(Scanner sc = new Scanner(System.in))
		{
			CricketService service = new CricketImplementation();
			boolean exit = false;
			System.out.println("1.Accept minimum 5 Cricketers in the collection.\r\n"
					+ "\r\n"
					+ "2.Modify Cricketer's rating\r\n"
					+ "\r\n"
					+ "3.Search Cricketer by name\r\n"
					+ "\r\n"
					+ "4.Display all Cricketers added in collection.\r\n"
					+ "\r\n"
					+ "5.Display All Cricketers in sorted form by rating.\r\n"
					+ "");
			while(!exit)
			{
				
				System.out.println("Enter choice");
				int choice = 0;
				try {
					switch(sc.nextInt())
					{
					case 1: 
						System.out.println("Enter 5 cricketers");
						//String name, int age, String email_id, String phone, int rating
//						System.out.println(service.addCricketer(sc.next() ,sc.nextInt(), sc.next(), sc.next(),sc.nextInt()));
						System.out.println(service.addCricketer("YashKalange", 21, "yk@gmail.com", "8530815940", 7007));
						System.out.println(service.addCricketer("Yshsd", 19, "yks@gmail.com", "85784", 1111));
						System.out.println(service.addCricketer("Yshsadasc", 19, "yk1@gmail.com", "85784", 19));
						System.out.println(service.addCricketer("Yshasdasdasdas", 19, "yk2@gmail.com", "85784", 110));
						System.out.println(service.addCricketer("Yshfsfasfasfasfa", 19, "yk3@gmail.com", "85784", 10));
						System.out.println(service.addCricketer("Yshdasfasvx", 19, "y5k@gmail.com", "85784", 90));
						System.out.println(service.addCricketer("YashKalange", 21, "yk@gmail.com", "8530815940", 7007));
						System.out.println(service.addCricketer("Yshdasf3asvx", 99, "y445k@gmail.com", "85784", 90));
						break;
						
					case 2:
						System.out.println("Modify Cricketer's rating\r\n");
						System.out.println("Enter email to change rating for \r\n");
						String email_id = sc.next();
						System.out.println("Enter new rating \r\n");
						int rating = sc.nextInt();
						System.out.println(service.changeRating(email_id, rating));
						break;
						
					case 3:
						System.out.println("Search by name \r\n");
						System.out.println("Enter email to search \r\n");
						String email_id1 = sc.next();
						System.out.println("Enter name to search \r\n");
						String nm = sc.next();
						service.searchCricketerByName(email_id1, nm);
						break;
						
					case 4:
						service.allCricketerSummary();
						break;
					case 5 :
						service.sortByRating();
						
					default:
						System.out.println("enter valid choice....");
						break;
						
					}
				}
				catch(Exception e)
				{
					sc.nextLine();
					System.out.println(e);
					
				}
			}
		}


	}

}
